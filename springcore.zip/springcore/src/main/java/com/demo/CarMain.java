package com.demo;
import java.util.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarMain {

	public static void main( String[] args )
	{
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		CarPojo b = (CarPojo) context.getBean("e");
		String action;
		Scanner sr=new Scanner(System.in);
		System.out.println("please enter action add,list,quit");
		action=sr.next();
		while(!action.equals("quit")) {

			switch(action)
			{
			case "add":

				System.out.println("enter the value for id=" ); 
				b.setId(sr.nextInt());
				System.out.println("enter the value for make=" );
				b.setMake(sr.next());
				System.out.println("enter the value for model=" );
				b.setModel(sr.next());
				System.out.println("enter the value for year=" );
				b.setYear(sr.nextInt());
				System.out.println("enter the value for price=" );
				b.setPrice(sr.nextFloat());
				carDao dao = context.getBean("cdao", carDao.class);
				dao.saveCardetails(b);
				System.out.println("data saved successfully");
				System.out.println("please enter action add,list,quit");
				action=sr.next();
				break;
			case "list":
				carDao dao1 = context.getBean("cdao", carDao.class);
				List<CarPojo> list1 = dao1.getCardetailsRowMapper();
				list1.forEach(carInfo->System.out.println(carInfo));
				System.out.println("please enter action add,list,quit");
				action=sr.next();
				break;
			default:
				System.out.println("please enter valid actions  add,list,quit");
				action=sr.next();	 
			}
		}
		System.out.println("Goodbye!!!!");
	}
}


