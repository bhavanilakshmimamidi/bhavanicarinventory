package com.demo;

public class CarPojo {
	private int id ;
	private String make;
	private String model;
	private int year;
	private float price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	
	public CarPojo() {
		super();
		
	}
	public String toString() {
        return id + " " + make + "  " + model +  " " + year +" " +price ;
    }
	

}
