package com.demo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class carDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void saveCardetails(CarPojo car) {
		String insertcarInfo = "insert into Cardetails values(" + car.getId() + ",'" + car.getMake() + " ' , ' " + car.getModel() + " ',"+ car.getYear() + ","+ car.getPrice() +  ")";
		jdbcTemplate.update(insertcarInfo);
	}

	public List<CarPojo> getCardetailsRowMapper() {
		return jdbcTemplate.query("select * from Cardetails", new RowMapper<CarPojo>() {
			public CarPojo mapRow(ResultSet rs, int rownumber) throws SQLException {
				CarPojo e = new CarPojo();
				e.setId(rs.getInt(1));
				e.setMake(rs.getString(2));
				e.setModel(rs.getString(3));
				e.setYear(rs.getInt(4));
				e.setPrice(rs.getFloat(5));
				return e;
			}
		});
	}
}
